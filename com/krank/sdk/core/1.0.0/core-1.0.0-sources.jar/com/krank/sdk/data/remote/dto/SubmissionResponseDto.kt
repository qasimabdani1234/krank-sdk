package com.krank.sdk.data.remote.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Response envelope. Every field is nullable with a default: the testing
 * endpoint echoes the request rather than returning a real envelope, and a real
 * backend may add fields before this SDK models them.
 */
@Serializable
internal data class SubmissionResponseDto(
    @SerialName("id") val id: String? = null,
    @SerialName("referenceId") val referenceId: String? = null,
    @SerialName("status") val status: String? = null,
    @SerialName("message") val message: String? = null,
)
