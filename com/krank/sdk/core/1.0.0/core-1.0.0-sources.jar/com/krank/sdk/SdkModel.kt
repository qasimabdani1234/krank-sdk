package com.krank.sdk

/**
 * Which AI model the SDK runs against.
 *
 * Passed to [FormSdk.init] together with the integration key. The [id] string is
 * the stable wire value — bridges (React Native / Flutter) send this string, not
 * the Kotlin enum name, so renaming a constant never breaks a JS/Dart caller.
 */
enum class SdkModel(val id: String, val displayName: String) {
    OPEN_AI("openai", "OpenAI"),
    GEMINI("gemini", "Gemini"),
    CLAUDE("claude", "Claude");

    companion object {
        /**
         * Resolves a wire value (or enum name) coming from a bridge.
         *
         * Returns `null` rather than guessing: picking the wrong model silently
         * would route a caller's traffic to a provider they did not ask for, so
         * an unknown value has to surface as an error at the call site.
         *
         * Matching ignores case and underscores, so `openai`, `OPEN_AI` and
         * `open_ai` all resolve to [OPEN_AI].
         */
        @JvmStatic
        fun from(raw: String?): SdkModel? {
            val normalised = raw?.replace("_", "")?.trim() ?: return null
            return entries.firstOrNull { it.id.equals(normalised, ignoreCase = true) }
        }
    }
}
