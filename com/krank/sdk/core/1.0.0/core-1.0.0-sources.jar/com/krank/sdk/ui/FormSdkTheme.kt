package com.krank.sdk.ui

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LightColors = lightColorScheme(
    primary = Color(0xFF2E5AAC),
    onPrimary = Color.White,
    secondary = Color(0xFF4E6591),
    surface = Color(0xFFFDFBFF),
    background = Color(0xFFFDFBFF),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFAFC6FF),
    onPrimary = Color(0xFF002E6B),
    secondary = Color(0xFFB7C8F8),
    surface = Color(0xFF1A1B1F),
    background = Color(0xFF1A1B1F),
)

/**
 * Theme for the SDK screen. Kept private to the SDK so the form looks identical
 * no matter what the host app's own theme is — important when the same screen is
 * embedded in a native, React Native and Flutter app.
 */
@Composable
internal fun FormSdkTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Material You is opt-in: it makes the form blend into the device wallpaper,
    // which some integrators want and others explicitly do not.
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }

        darkTheme -> DarkColors
        else -> LightColors
    }

    MaterialTheme(colorScheme = colorScheme, content = content)
}
