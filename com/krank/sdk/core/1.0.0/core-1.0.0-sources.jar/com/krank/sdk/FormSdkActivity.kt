package com.krank.sdk

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.krank.sdk.model.FormResult
import com.krank.sdk.ui.FormScreen
import com.krank.sdk.ui.FormSdkTheme
import com.krank.sdk.ui.FormViewModel
import com.krank.sdk.ui.FormViewModelFactory

/**
 * The SDK's form screen.
 *
 * Declared in the SDK's own manifest, so the manifest merger adds it to every
 * consuming app automatically — host apps register nothing.
 *
 * Not meant to be started directly: use [FormSdkContract].
 */
class FormSdkActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (!FormSdk.isInitialized) {
            finishWith(FormResult.Failed("FormSdk.init(key, model) was never called"))
            return
        }

        enableEdgeToEdge()

        val configuration = FormSdk.requireConfiguration()

        setContent {
            FormSdkTheme {
                val viewModel: FormViewModel = viewModel(factory = FormViewModelFactory(configuration))
                val state by viewModel.uiState.collectAsStateWithLifecycle()

                // One-shot: fires once per successful submission, never on rotation.
                LaunchedEffect(viewModel) {
                    viewModel.submitted.collect { result ->
                        finishWith(FormResult.Submitted(result.values, result.response))
                    }
                }

                FormScreen(
                    state = state,
                    onFullNameChange = viewModel::onFullNameChange,
                    onEmailChange = viewModel::onEmailChange,
                    onPhoneChange = viewModel::onPhoneChange,
                    onAmountChange = viewModel::onAmountChange,
                    onSubmit = viewModel::onSubmit,
                    onDismissError = viewModel::onDismissError,
                    onClose = { finishWith(FormResult.Cancelled) },
                )
            }
        }
    }

    private fun finishWith(result: FormResult) {
        if (result is FormResult.Cancelled) {
            // No payload to carry — a plain cancel keeps the contract simple.
            setResult(Activity.RESULT_CANCELED)
        } else {
            setResult(Activity.RESULT_OK, Intent().putExtra(EXTRA_RESULT, result.toJsonString()))
        }
        finish()
    }

    companion object {
        /** JSON [FormResult] handed back to the caller. */
        const val EXTRA_RESULT = "com.krank.sdk.extra.RESULT"

        @JvmStatic
        fun createIntent(context: Context): Intent =
            Intent(context, FormSdkActivity::class.java)
    }
}
