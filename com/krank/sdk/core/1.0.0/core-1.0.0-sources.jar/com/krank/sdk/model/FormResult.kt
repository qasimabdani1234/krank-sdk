package com.krank.sdk.model

import org.json.JSONObject

/** Outcome of one run of the SDK form screen. */
sealed class FormResult {

    /**
     * The user passed validation, the SDK posted the form, and the backend
     * accepted it. [values] is what was typed; [response] is what came back.
     */
    data class Submitted(
        val values: Map<String, String>,
        val response: SubmissionResponse,
    ) : FormResult()

    /** User backed out via the close button or the system back gesture. */
    data object Cancelled : FormResult()

    /** The screen could not run — e.g. the SDK was never initialised. */
    data class Failed(val message: String) : FormResult()

    fun toJson(): JSONObject = JSONObject().apply {
        when (this@FormResult) {
            is Submitted -> {
                put(KEY_STATUS, STATUS_SUBMITTED)
                put(KEY_VALUES, JSONObject(values as Map<*, *>))
                put(KEY_RESPONSE, response.toJson())
            }

            Cancelled -> put(KEY_STATUS, STATUS_CANCELLED)

            is Failed -> {
                put(KEY_STATUS, STATUS_FAILED)
                put(KEY_MESSAGE, message)
            }
        }
    }

    fun toJsonString(): String = toJson().toString()

    companion object {
        const val STATUS_SUBMITTED = "submitted"
        const val STATUS_CANCELLED = "cancelled"
        const val STATUS_FAILED = "failed"

        private const val KEY_STATUS = "status"
        private const val KEY_VALUES = "values"
        private const val KEY_RESPONSE = "response"
        private const val KEY_MESSAGE = "message"

        @JvmStatic
        fun fromJsonString(raw: String?): FormResult {
            if (raw.isNullOrBlank()) return Cancelled
            return runCatching {
                val json = JSONObject(raw)
                when (json.optString(KEY_STATUS)) {
                    STATUS_SUBMITTED -> {
                        val values = json.optJSONObject(KEY_VALUES) ?: JSONObject()
                        Submitted(
                            values = values.keys().asSequence().associateWith { values.optString(it) },
                            response = SubmissionResponse.fromJson(
                                json.optJSONObject(KEY_RESPONSE) ?: JSONObject()
                            ),
                        )
                    }

                    STATUS_FAILED -> Failed(json.optString(KEY_MESSAGE).ifBlank { "Unknown error" })
                    else -> Cancelled
                }
            }.getOrElse { Failed(it.message ?: "Malformed SDK result") }
        }
    }
}
