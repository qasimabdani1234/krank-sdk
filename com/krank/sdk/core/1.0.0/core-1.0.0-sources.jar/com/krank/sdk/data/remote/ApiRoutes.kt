package com.krank.sdk.data.remote

/**
 * Relative API routes, resolved against the base URL passed to `FormSdk.init`.
 * Every route the SDK calls is named here, never inline in a repository.
 */
internal object ApiRoutes {

    /** Testing route on the placeholder backend; the real one might be `v1/submissions`. */
    const val SUBMIT = "posts"
}
