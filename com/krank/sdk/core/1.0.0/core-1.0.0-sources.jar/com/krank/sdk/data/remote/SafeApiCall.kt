package com.krank.sdk.data.remote

import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import kotlinx.coroutines.CancellationException

/** Outcome of one API call, with the body already decoded to [T]. */
internal sealed interface ApiResult<out T> {
    data class Success<T>(val data: T, val rawBody: String) : ApiResult<T>
    data class Error(val message: String) : ApiResult<Nothing>
}

/**
 * Shared error handling for every API call the SDK makes: HTTP status check,
 * JSON decoding and network failures are dealt with here once, so repositories
 * never repeat a try/catch.
 */
internal suspend inline fun <reified T> safeApiCall(
    call: () -> HttpResponse,
): ApiResult<T> = try {
    val response = call()
    val body = response.bodyAsText()

    if (response.status.value in 200..299) {
        runCatching { ApiResult.Success(SdkJson.decodeFromString<T>(body), body) }
            .getOrElse { ApiResult.Error("The server sent a response this app could not read.") }
    } else {
        ApiResult.Error("Request rejected by the server (HTTP ${response.status.value}).")
    }
} catch (cancellation: CancellationException) {
    // Structured concurrency: a cancelled screen must not look like a failure.
    throw cancellation
} catch (error: Throwable) {
    ApiResult.Error("Could not reach the server. Check your connection and try again.")
}
