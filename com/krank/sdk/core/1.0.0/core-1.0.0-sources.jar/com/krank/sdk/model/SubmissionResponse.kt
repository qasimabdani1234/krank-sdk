package com.krank.sdk.model

import org.json.JSONObject

/**
 * What the backend returned for a successful submission.
 *
 * [rawJson] is always the untouched response body, so a host app can read
 * fields this SDK version does not model yet without waiting for an SDK update.
 */
data class SubmissionResponse(
    val referenceId: String,
    val status: String,
    val message: String,
    val rawJson: String,
) {
    internal fun toJson(): JSONObject = JSONObject().apply {
        put(KEY_REFERENCE_ID, referenceId)
        put(KEY_STATUS, status)
        put(KEY_MESSAGE, message)
        put(KEY_RAW_JSON, rawJson)
    }

    internal companion object {
        private const val KEY_REFERENCE_ID = "referenceId"
        private const val KEY_STATUS = "status"
        private const val KEY_MESSAGE = "message"
        private const val KEY_RAW_JSON = "rawJson"

        fun fromJson(json: JSONObject): SubmissionResponse = SubmissionResponse(
            referenceId = json.optString(KEY_REFERENCE_ID),
            status = json.optString(KEY_STATUS),
            message = json.optString(KEY_MESSAGE),
            rawJson = json.optString(KEY_RAW_JSON),
        )
    }
}
