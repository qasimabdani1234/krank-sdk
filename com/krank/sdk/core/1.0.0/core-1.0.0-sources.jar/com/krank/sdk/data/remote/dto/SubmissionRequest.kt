package com.krank.sdk.data.remote.dto

import kotlinx.serialization.Serializable

/** Body posted to the submission endpoint. */
@Serializable
internal data class SubmissionRequest(
    val model: String,
    val fullName: String,
    val email: String,
    val phone: String,
    val amount: String,
)
