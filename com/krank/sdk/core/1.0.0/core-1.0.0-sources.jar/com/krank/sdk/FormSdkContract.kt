package com.krank.sdk

import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.activity.result.contract.ActivityResultContract
import com.krank.sdk.model.FormResult

/**
 * The way to open the SDK form:
 *
 * ```
 * private val form = registerForActivityResult(FormSdkContract()) { result ->
 *     when (result) {
 *         is FormResult.Submitted -> println(result.values)
 *         FormResult.Cancelled    -> Unit
 *         is FormResult.Failed    -> println(result.message)
 *     }
 * }
 *
 * form.launch(Unit)
 * ```
 */
class FormSdkContract : ActivityResultContract<Unit, FormResult>() {

    override fun createIntent(context: Context, input: Unit): Intent =
        FormSdkActivity.createIntent(context)

    override fun parseResult(resultCode: Int, intent: Intent?): FormResult =
        if (resultCode == Activity.RESULT_OK) {
            FormResult.fromJsonString(intent?.getStringExtra(FormSdkActivity.EXTRA_RESULT))
        } else {
            FormResult.Cancelled
        }
}
