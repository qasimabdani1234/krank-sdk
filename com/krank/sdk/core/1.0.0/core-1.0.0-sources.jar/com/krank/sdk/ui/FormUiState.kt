package com.krank.sdk.ui

/** Everything [FormScreen] needs to render. */
internal data class FormUiState(
    val fullName: String = "",
    val email: String = "",
    val phone: String = "",
    val amount: String = "",
    val isSubmitting: Boolean = false,
    val error: String? = null,
)
