package com.krank.sdk.data

import com.krank.sdk.model.SubmissionResponse

/** What the ViewModel gets back — no HTTP vocabulary past this point. */
internal sealed interface SubmitOutcome {
    data class Success(val response: SubmissionResponse) : SubmitOutcome
    data class Failure(val message: String) : SubmitOutcome
}
