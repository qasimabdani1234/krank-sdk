package com.krank.sdk

import android.content.Context
import android.content.Intent

/**
 * Entry point of the SDK.
 *
 * Integrators do exactly two things:
 * ```
 * FormSdk.init("<your-key>", SdkModel.CLAUDE)    // once, e.g. in Application.onCreate
 * form.launch(Unit)                              // see FormSdkContract
 * ```
 *
 * The form itself is a self-contained activity shipped inside the SDK's own
 * manifest, so a host app never declares an activity, a theme, a permission or
 * a dependency of its own.
 */
object FormSdk {

    /**
     * Placeholder backend. Its `posts` route echoes whatever JSON it is posted
     * and adds an `id`, which is enough to exercise the full request → response
     * → host-app round trip. Swap it for the real backend by passing `baseUrl`
     * to [init]; the per-call routes live in `data/remote/ApiRoutes.kt`.
     */
    const val TESTING_BASE_URL = "https://jsonplaceholder.typicode.com/"

    /** Immutable snapshot of what [init] was called with. */
    data class Configuration(
        val integrationKey: String,
        val model: SdkModel,
        val baseUrl: String,
    )

    @Volatile
    private var configuration: Configuration? = null

    /**
     * Arms the SDK. Safe to call more than once — the last call wins, which is
     * what lets a React Native / Flutter host switch models at runtime.
     *
     * @param baseUrl defaults to [TESTING_BASE_URL]; point it at the real
     *   backend in production.
     * @throws IllegalArgumentException when [integrationKey] or [baseUrl] is blank.
     */
    @JvmStatic
    @JvmOverloads
    fun init(
        integrationKey: String,
        model: SdkModel,
        baseUrl: String = TESTING_BASE_URL,
    ) {
        require(integrationKey.isNotBlank()) { "integrationKey must not be blank" }
        require(baseUrl.isNotBlank()) { "baseUrl must not be blank" }
        configuration = Configuration(integrationKey, model, baseUrl)
    }

    /** True once [init] has completed successfully. */
    @JvmStatic
    val isInitialized: Boolean
        get() = configuration != null

    /**
     * The configuration passed to [init].
     * @throws IllegalStateException if [init] was never called.
     */
    @JvmStatic
    fun requireConfiguration(): Configuration = checkNotNull(configuration) {
        "FormSdk.init(key, model) must be called before the form can be shown"
    }

    /** The key passed to [init], or `null` when not initialised yet. */
    @JvmStatic
    val integrationKey: String?
        get() = configuration?.integrationKey

    /** The model passed to [init], or `null` when not initialised yet. */
    @JvmStatic
    val model: SdkModel?
        get() = configuration?.model

    /**
     * Builds the intent that opens the form. Prefer [FormSdkContract] on native
     * Android; this exists for bridges that drive `startActivityForResult`
     * themselves.
     */
    @JvmStatic
    fun createIntent(context: Context): Intent = FormSdkActivity.createIntent(context)

    /** Clears state. Intended for tests and for host apps that log a user out. */
    @JvmStatic
    fun reset() {
        configuration = null
    }
}
