package com.krank.sdk.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.krank.sdk.FormSdk
import com.krank.sdk.data.FormRepository

/**
 * The SDK's single composition point — constructor injection everywhere else,
 * so no DI framework is needed (and none could be: Hilt requires the host
 * Application to be @HiltAndroidApp, which an SDK cannot demand of its hosts).
 */
internal class FormViewModelFactory(
    private val config: FormSdk.Configuration,
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T =
        FormViewModel(FormRepository(config.model)) as T
}
