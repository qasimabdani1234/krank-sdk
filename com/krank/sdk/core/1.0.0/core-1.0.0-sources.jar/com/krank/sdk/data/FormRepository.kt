package com.krank.sdk.data

import com.krank.sdk.SdkModel
import com.krank.sdk.data.remote.ApiResult
import com.krank.sdk.data.remote.ApiRoutes
import com.krank.sdk.data.remote.SdkHttpClient
import com.krank.sdk.data.remote.dto.SubmissionRequest
import com.krank.sdk.data.remote.dto.SubmissionResponseDto
import com.krank.sdk.data.remote.safeApiCall
import com.krank.sdk.model.SubmissionResponse
import io.ktor.client.request.post
import io.ktor.client.request.setBody

internal class FormRepository(
    private val model: SdkModel,
) {

    suspend fun submit(
        fullName: String,
        email: String,
        phone: String,
        amount: String,
    ): SubmitOutcome {
        val result = safeApiCall<SubmissionResponseDto> {
            SdkHttpClient.client.post(ApiRoutes.SUBMIT) {
                setBody(
                    SubmissionRequest(
                        model = model.id,
                        fullName = fullName,
                        email = email,
                        phone = phone,
                        amount = amount,
                    )
                )
            }
        }

        return when (result) {
            is ApiResult.Success -> SubmitOutcome.Success(result.data.toSubmissionResponse(result.rawBody))
            is ApiResult.Error -> SubmitOutcome.Failure(result.message)
        }
    }

    private fun SubmissionResponseDto.toSubmissionResponse(rawBody: String) = SubmissionResponse(
        // The testing endpoint echoes the request and adds an `id`, so fall
        // back through the shapes a real backend might send.
        referenceId = referenceId ?: id.orEmpty(),
        status = status ?: "accepted",
        message = message ?: "Submission received",
        rawJson = rawBody,
    )
}
