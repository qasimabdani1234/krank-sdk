package com.krank.sdk.data.remote

import com.krank.sdk.FormSdk
import io.ktor.client.HttpClient
import io.ktor.client.engine.android.Android
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.defaultRequest
import io.ktor.client.request.header
import io.ktor.http.ContentType
import io.ktor.http.contentType
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.json.Json

/** JSON settings shared by request encoding and response decoding. */
internal val SdkJson: Json = Json {
    // A backend adding a field must never break an older SDK build.
    ignoreUnknownKeys = true
    isLenient = true
}

/**
 * The SDK's single, process-wide Ktor client.
 *
 * Everything common to every API call lives here once — base URL, the
 * `X-Api-Key` header and the JSON content type — so repositories only name a
 * route from [ApiRoutes] and set a body.
 *
 * One client is deliberate: each [HttpClient] owns a connection pool and a
 * dispatcher, so building one per call would leak threads. The Android engine
 * (HttpURLConnection) is used on purpose so the SDK does not drag OkHttp into
 * host apps.
 */
internal object SdkHttpClient {

    private const val HEADER_API_KEY = "X-Api-Key"

    val client: HttpClient by lazy {
        HttpClient(Android) {
            // Non-2xx is data that safeApiCall maps to a message, not an exception.
            expectSuccess = false

            install(ContentNegotiation) { json(SdkJson) }

            install(HttpTimeout) {
                requestTimeoutMillis = 30_000
                connectTimeoutMillis = 15_000
                socketTimeoutMillis = 30_000
            }

            // Runs for every request, so it always reflects the latest init()
            // call — the key identifies the integration and stays out of the
            // body, where a logging or debug endpoint could echo it back.
            defaultRequest {
                val config = FormSdk.requireConfiguration()
                url(config.baseUrl)
                header(HEADER_API_KEY, config.integrationKey)
                contentType(ContentType.Application.Json)
            }
        }
    }
}
