package com.krank.sdk.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.krank.sdk.data.FormRepository
import com.krank.sdk.data.SubmitOutcome
import com.krank.sdk.model.SubmissionResponse
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

internal class FormViewModel(
    private val repository: FormRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(FormUiState())
    val uiState: StateFlow<FormUiState> = _uiState.asStateFlow()

    /**
     * One-shot "we're done" signal. A Channel rather than state, so a successful
     * submission closes the screen exactly once and never replays on rotation.
     */
    private val _submitted = Channel<SubmissionResult>(Channel.BUFFERED)
    val submitted = _submitted.receiveAsFlow()

    data class SubmissionResult(
        val values: Map<String, String>,
        val response: SubmissionResponse,
    )

    fun onFullNameChange(value: String) = _uiState.update { it.copy(fullName = value, error = null) }
    fun onEmailChange(value: String) = _uiState.update { it.copy(email = value, error = null) }
    fun onPhoneChange(value: String) = _uiState.update { it.copy(phone = value, error = null) }
    fun onAmountChange(value: String) = _uiState.update { it.copy(amount = value, error = null) }

    fun onSubmit() {
        val state = _uiState.value
        if (state.isSubmitting) return

        _uiState.update { it.copy(isSubmitting = true, error = null) }

        viewModelScope.launch {
            val outcome = repository.submit(
                fullName = state.fullName.trim(),
                email = state.email.trim(),
                phone = state.phone.trim(),
                amount = state.amount.trim(),
            )

            when (outcome) {
                is SubmitOutcome.Success -> {
                    // Leave isSubmitting true: the screen is closing, and letting
                    // the button go live again would allow a double submit.
                    _submitted.send(
                        SubmissionResult(
                            values = mapOf(
                                "fullName" to state.fullName.trim(),
                                "email" to state.email.trim(),
                                "phone" to state.phone.trim(),
                                "amount" to state.amount.trim(),
                            ),
                            response = outcome.response,
                        )
                    )
                }

                is SubmitOutcome.Failure -> _uiState.update {
                    it.copy(isSubmitting = false, error = outcome.message)
                }
            }
        }
    }

    fun onDismissError() = _uiState.update { it.copy(error = null) }
}
